/* ============================================================
   algos.js — Advanced algorithm library for CareTree
   String matching: KMP / Z-function / Rabin-Karp
   Network flow: Edmonds-Karp max-flow / min-cut
   Approximation: vertex cover, LPT scheduling
   Randomized & parallel: quickselect, Monte Carlo, prefix sum, reduce
   ============================================================ */
'use strict';

const Algo = {

  /* ── String matching ──────────────────────────────────── */
  naive(text, pat) {
    const n = text.length, m = pat.length, matches = []; let comps = 0;
    if (!m) return { matches, comps };
    for (let i = 0; i <= n - m; i++) {
      let j = 0;
      for (; j < m; j++) { comps++; if (text[i + j] !== pat[j]) break; }
      if (j === m) matches.push(i);
    }
    return { matches, comps };
  },

  kmp(text, pat) {
    const n = text.length, m = pat.length, matches = []; let comps = 0;
    if (!m) return { matches, comps };
    const lps = new Array(m).fill(0);
    for (let i = 1, len = 0; i < m;) {
      comps++;
      if (pat[i] === pat[len]) { lps[i++] = ++len; }
      else if (len) { len = lps[len - 1]; }
      else { lps[i++] = 0; }
    }
    for (let i = 0, j = 0; i < n;) {
      comps++;
      if (text[i] === pat[j]) {
        i++; j++;
        if (j === m) { matches.push(i - j); j = lps[j - 1]; }
      } else if (j) { j = lps[j - 1]; }
      else { i++; }
    }
    return { matches, comps };
  },

  zsearch(text, pat) {
    const m = pat.length, matches = []; let comps = 0;
    if (!m) return { matches, comps };
    const s = pat + '\u0001' + text, L = s.length, z = new Array(L).fill(0);
    for (let i = 1, l = 0, r = 0; i < L; i++) {
      if (i < r) z[i] = Math.min(r - i, z[i - l]);
      while (i + z[i] < L) {
        comps++;
        if (s[z[i]] === s[i + z[i]]) z[i]++; else break;
      }
      if (i + z[i] > r) { l = i; r = i + z[i]; }
    }
    for (let i = m + 1; i < L; i++) if (z[i] >= m) matches.push(i - m - 1);
    return { matches, comps };
  },

  rabinKarp(text, pat) {
    const n = text.length, m = pat.length, matches = [];
    let comps = 0, spurious = 0;
    if (!m || m > n) return { matches, comps, spurious };
    const B = 256, M = 1000003;
    let hp = 0, ht = 0, pow = 1;
    for (let i = 0; i < m - 1; i++) pow = (pow * B) % M;
    for (let i = 0; i < m; i++) {
      hp = (hp * B + pat.charCodeAt(i)) % M;
      ht = (ht * B + text.charCodeAt(i)) % M;
    }
    for (let i = 0; i <= n - m; i++) {
      comps++;                                   // one hash comparison
      if (hp === ht) {
        let ok = true;
        for (let j = 0; j < m; j++) { comps++; if (text[i + j] !== pat[j]) { ok = false; break; } }
        if (ok) matches.push(i); else spurious++;
      }
      if (i < n - m) ht = ((ht - (text.charCodeAt(i) * pow) % M + M) * B + text.charCodeAt(i + m)) % M;
    }
    return { matches, comps, spurious };
  },

  /* ── Edmonds-Karp max-flow / min-cut ──────────────────── */
  edmondsKarp(n, cap, s, t) {
    const flow = Array.from({ length: n }, () => new Array(n).fill(0));
    let total = 0; const paths = [];
    while (true) {
      const parent = new Array(n).fill(-1); parent[s] = s;
      const q = [s];
      while (q.length && parent[t] === -1) {
        const u = q.shift();
        for (let v = 0; v < n; v++)
          if (parent[v] === -1 && cap[u][v] - flow[u][v] > 0) { parent[v] = u; q.push(v); }
      }
      if (parent[t] === -1) break;
      let b = Infinity;
      for (let v = t; v !== s; v = parent[v]) b = Math.min(b, cap[parent[v]][v] - flow[parent[v]][v]);
      const path = [];
      for (let v = t; v !== s; v = parent[v]) { flow[parent[v]][v] += b; flow[v][parent[v]] -= b; path.unshift(v); }
      path.unshift(s);
      total += b; paths.push({ path, bottleneck: b });
    }
    const seen = new Array(n).fill(false); seen[s] = true;
    const q = [s];
    while (q.length) {
      const u = q.shift();
      for (let v = 0; v < n; v++) if (!seen[v] && cap[u][v] - flow[u][v] > 0) { seen[v] = true; q.push(v); }
    }
    const cutEdges = [];
    for (let u = 0; u < n; u++) if (seen[u])
      for (let v = 0; v < n; v++) if (!seen[v] && cap[u][v] > 0) cutEdges.push([u, v, cap[u][v]]);
    return { maxFlow: total, flow, paths, reachable: seen, cutEdges };
  },

  /* ── Approximation algorithms ─────────────────────────── */
  vertexCover2(n, edges) {                       // maximal-matching 2-approximation
    const inC = new Array(n).fill(false), matching = [];
    for (const [u, v] of edges)
      if (!inC[u] && !inC[v]) { inC[u] = inC[v] = true; matching.push([u, v]); }
    return { cover: inC.map((x, i) => x ? i : -1).filter(i => i >= 0), matching };
  },
  vertexCoverExact(n, edges) {                   // brute force, n <= 16
    let best = null;
    for (let mask = 0; mask < (1 << n); mask++) {
      if (best !== null && popcount(mask) >= best.length) continue;
      if (edges.every(([u, v]) => (mask >> u & 1) || (mask >> v & 1))) {
        best = []; for (let i = 0; i < n; i++) if (mask >> i & 1) best.push(i);
      }
    }
    return best || [];
  },
  lpt(times, m) {                                // Longest Processing Time first: 4/3-approx
    const load = new Array(m).fill(0), assign = Array.from({ length: m }, () => []);
    const order = times.map((t, i) => [t, i]).sort((a, b) => b[0] - a[0]);
    for (const [t, i] of order) {
      let k = 0; for (let x = 1; x < m; x++) if (load[x] < load[k]) k = x;
      load[k] += t; assign[k].push(i);
    }
    return { makespan: Math.max(...load), load, assign };
  },
  optMakespan(times, m) {                        // brute force, m^n assignments (n <= 10)
    const n = times.length; let best = Infinity;
    const load = new Array(m).fill(0);
    (function rec(i) {
      if (i === n) { best = Math.min(best, Math.max(...load)); return; }
      const seen = new Set();
      for (let k = 0; k < m; k++) {
        if (seen.has(load[k])) continue; seen.add(load[k]);
        load[k] += times[i];
        if (Math.max(...load) < best) rec(i + 1);
        load[k] -= times[i];
      }
    })(0);
    return best;
  },


  /* ── Sequence alignment (edit distance with traceback) ── */
  editDistance(a, b) {
    const n = a.length, m = b.length;
    const d = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = 0; i <= n; i++) d[i][0] = i;
    for (let j = 0; j <= m; j++) d[0][j] = j;
    for (let i = 1; i <= n; i++)
      for (let j = 1; j <= m; j++)
        d[i][j] = Math.min(d[i-1][j] + 1, d[i][j-1] + 1, d[i-1][j-1] + (a[i-1] === b[j-1] ? 0 : 1));
    let i = n, j = m, A = '', B = '', ops = '';
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && d[i][j] === d[i-1][j-1] + (a[i-1] === b[j-1] ? 0 : 1)) {
        A = a[i-1] + A; B = b[j-1] + B; ops = (a[i-1] === b[j-1] ? '=' : '~') + ops; i--; j--;
      } else if (i > 0 && d[i][j] === d[i-1][j] + 1) { A = a[i-1] + A; B = '-' + B; ops = '-' + ops; i--; }
      else { A = '-' + A; B = b[j-1] + B; ops = '+' + ops; j--; }
    }
    return { dist: d[n][m], table: d, alignA: A, alignB: B, ops };
  },

  /* ── Suffix array + LCP (Kasai) ── */
  suffixArray(s) {
    return Array.from({ length: s.length }, (_, i) => i).sort((x, y) => {
      const a = s.slice(x), b = s.slice(y); return a < b ? -1 : a > b ? 1 : 0;
    });
  },
  lcpArray(s, sa) {
    const n = s.length, rank = new Array(n), lcp = new Array(n).fill(0);
    sa.forEach((p, i) => rank[p] = i);
    for (let i = 0, h = 0; i < n; i++) {
      if (rank[i] > 0) {
        const j = sa[rank[i] - 1];
        while (i + h < n && j + h < n && s[i + h] === s[j + h]) h++;
        lcp[rank[i]] = h; if (h > 0) h--;
      } else h = 0;
    }
    return lcp;
  },
  saSearch(s, sa, pat) {
    const m = pat.length; let lo = 0, hi = sa.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (s.substr(sa[mid], m) < pat) lo = mid + 1; else hi = mid; }
    const left = lo; hi = sa.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (s.substr(sa[mid], m) <= pat) lo = mid + 1; else hi = mid; }
    return { left, right: lo, count: lo - left, positions: sa.slice(left, lo).sort((a, b) => a - b) };
  },

  /* ── DP over intervals — weighted interval scheduling ── */
  weightedIntervals(items) {                     // items: [{s, e, w}]
    const it = items.map((x, i) => ({ ...x, i })).sort((a, b) => a.e - b.e);
    const n = it.length, dp = new Array(n + 1).fill(0), prev = new Array(n).fill(-1);
    for (let k = 0; k < n; k++) {                 // last interval finishing at or before it[k].s
      let lo = 0, hi = k - 1, r = -1;
      while (lo <= hi) { const mid = (lo + hi) >> 1; if (it[mid].e <= it[k].s) { r = mid; lo = mid + 1; } else hi = mid - 1; }
      prev[k] = r;
    }
    for (let k = 1; k <= n; k++) dp[k] = Math.max(dp[k-1], it[k-1].w + dp[prev[k-1] + 1]);
    const chosen = []; let k = n;
    while (k > 0) { if (it[k-1].w + dp[prev[k-1] + 1] >= dp[k-1]) { chosen.push(it[k-1].i); k = prev[k-1] + 1; } else k--; }
    return { best: dp[n], chosen: chosen.reverse() };
  },

  /* ── DP on subsets — 0/1 selection under a budget ── */
  subsetKnapsack(items, budget) {                // items: [{cost, value}], integer costs
    const n = items.length, dp = Array.from({ length: n + 1 }, () => new Array(budget + 1).fill(0));
    for (let i = 1; i <= n; i++)
      for (let b = 0; b <= budget; b++) {
        dp[i][b] = dp[i-1][b];
        if (items[i-1].cost <= b) dp[i][b] = Math.max(dp[i][b], dp[i-1][b - items[i-1].cost] + items[i-1].value);
      }
    const chosen = []; let b = budget;
    for (let i = n; i > 0; i--) if (dp[i][b] !== dp[i-1][b]) { chosen.push(i - 1); b -= items[i-1].cost; }
    return { best: dp[n][budget], chosen: chosen.reverse(), cells: (n + 1) * (budget + 1) };
  },

  /* ── Bitmask DP — assign doctors to duty slots at minimum total cost ── */
  bitmaskAssign(cost, S) {                       // cost[d][s], doctors >= slots
    const D = cost.length, FULL = (1 << S) - 1, INF = 1e9;
    const dp = Array.from({ length: D + 1 }, () => new Array(1 << S).fill(INF));
    const from = Array.from({ length: D + 1 }, () => new Array(1 << S).fill(null));
    dp[0][0] = 0;
    for (let i = 0; i < D; i++)
      for (let mask = 0; mask <= FULL; mask++) {
        if (dp[i][mask] >= INF) continue;
        if (dp[i][mask] < dp[i+1][mask]) { dp[i+1][mask] = dp[i][mask]; from[i+1][mask] = { mask, slot: -1 }; }
        for (let s = 0; s < S; s++) if (!((mask >> s) & 1)) {
          const nm = mask | (1 << s), c = dp[i][mask] + cost[i][s];
          if (c < dp[i+1][nm]) { dp[i+1][nm] = c; from[i+1][nm] = { mask, slot: s }; }
        }
      }
    if (dp[D][FULL] >= INF) return null;
    const assign = new Array(S).fill(-1); let mask = FULL;
    for (let i = D; i > 0; i--) { const f = from[i][mask]; if (f.slot >= 0) assign[f.slot] = i - 1; mask = f.mask; }
    return { total: dp[D][FULL], assign, states: D * (1 << S) };
  },
  greedyAssign(cost, S) {                        // baseline: slot by slot, cheapest free doctor
    const used = new Set(), assign = []; let total = 0;
    for (let s = 0; s < S; s++) {
      let best = -1;
      cost.forEach((row, d) => { if (!used.has(d) && (best < 0 || row[s] < cost[best][s])) best = d; });
      used.add(best); assign.push(best); total += cost[best][s];
    }
    return { total, assign };
  },

  /* ── DP on trees — minimum-cost vertex cover of a tree ── */
  treeVertexCover(nodes, rootId) {               // nodes: {id: {cost, children: [ids]}}
    const inC = {}, outC = {};
    (function dfs(v) {
      inC[v] = nodes[v].cost; outC[v] = 0;
      for (const c of nodes[v].children) { dfs(c); inC[v] += Math.min(inC[c], outC[c]); outC[v] += inC[c]; }
    })(rootId);
    const chosen = [];
    (function pick(v, parentChosen) {            // if the parent is not chosen, v must be
      const take = parentChosen ? inC[v] <= outC[v] : true;
      if (take) chosen.push(v);
      for (const c of nodes[v].children) pick(c, take);
    })(rootId, true);
    return { best: Math.min(inC[rootId], outC[rootId]), chosen, inC, outC };
  },

  /* ── Randomized ────────────────────────────────────────── */
  quickselect(arr, k) {                          // Las Vegas: always correct, random running time
    const a = arr.slice(); let comps = 0, lo = 0, hi = a.length - 1;
    while (true) {
      if (lo === hi) return { value: a[lo], comps };
      const p = lo + Math.floor(Math.random() * (hi - lo + 1));
      [a[p], a[hi]] = [a[hi], a[p]];
      const pv = a[hi]; let i = lo;
      for (let j = lo; j < hi; j++) { comps++; if (a[j] < pv) { [a[i], a[j]] = [a[j], a[i]]; i++; } }
      [a[i], a[hi]] = [a[hi], a[i]];
      if (k === i) return { value: a[i], comps };
      if (k < i) hi = i - 1; else lo = i + 1;
    }
  },
  monteCarloFraction(arr, pred, samples) {       // Monte Carlo: fast, approximate
    let hits = 0;
    for (let i = 0; i < samples; i++) if (pred(arr[Math.floor(Math.random() * arr.length)])) hits++;
    return hits / samples;
  },

  /* ── Parallel primitives (simulated rounds) ───────────── */
  parallelPrefix(arr) {                          // Hillis-Steele scan: span O(log n)
    let a = arr.slice(); const rounds = [a.slice()]; let work = 0;
    for (let d = 1; d < a.length; d *= 2) {
      const b = a.slice();
      for (let i = d; i < a.length; i++) { b[i] = a[i] + a[i - d]; work++; }
      a = b; rounds.push(a.slice());
    }
    return { result: a, rounds, work, span: rounds.length - 1 };
  },
  parallelReduce(arr) {                          // tree reduction: work n-1, span ceil(log2 n)
    let a = arr.slice(); const rounds = [a.slice()]; let work = 0;
    while (a.length > 1) {
      const b = [];
      for (let i = 0; i < a.length; i += 2) {
        if (i + 1 < a.length) { b.push(a[i] + a[i + 1]); work++; } else b.push(a[i]);
      }
      a = b; rounds.push(a.slice());
    }
    return { total: a[0], rounds, work, span: rounds.length - 1 };
  },
};

function popcount(x) { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; }

if (typeof module !== 'undefined') module.exports = Algo;
