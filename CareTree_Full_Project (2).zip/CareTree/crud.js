/* ============================================================
   crud.js — reusable table + add/edit modal for hospital modules
   Search box uses KMP string matching from algos.js.
   cfg = { mount, store, title, icon, addLabel, fields, columns,
           searchText(row), onChange(), sort(a,b) }
   field   = { name, label, type:'text|number|select|date|time', options,
               required, full, placeholder, min, max }
   column  = { label, render(row) }   (html string)
   ============================================================ */
'use strict';
window.__crud = window.__crud || {};

function mountCrud(cfg) {
  const id = cfg.mount;
  const root = document.getElementById(id);
  let editId = null;

  const optsOf = f => (typeof f.options === 'function' ? f.options() : f.options || [])
    .map(o => typeof o === 'string' ? { value: o, label: o } : o);

  root.innerHTML = `
    <div class="card">
      <div class="card-hd">
        <div class="card-hd-icon">${cfg.icon || '📋'}</div>
        <div class="card-title">${cfg.title}</div>
        <button class="btn btn-primary btn-sm" onclick="__crud['${id}'].openAdd()">➕ ${cfg.addLabel || 'Add'}</button>
      </div>
      <div class="card-body" style="padding:12px 22px">
        <div class="search-wrap"><span class="search-ico">🔍</span>
          <input type="text" id="${id}-q" placeholder="Search (KMP string matching)…" oninput="__crud['${id}'].render()">
        </div>
      </div>
      <div class="tbl-wrap"><table>
        <thead><tr>${cfg.columns.map(c => `<th>${c.label}</th>`).join('')}<th>Actions</th></tr></thead>
        <tbody id="${id}-body"></tbody>
      </table></div>
    </div>
    <div class="overlay" id="${id}-modal">
      <div class="modal">
        <div class="modal-hd">
          <div class="modal-hd-icon">${cfg.icon || '📋'}</div>
          <div class="modal-title" id="${id}-mt"></div>
          <button class="modal-close" onclick="hideModal('${id}-modal')">✕</button>
        </div>
        <div class="modal-body"><div class="form-row" id="${id}-form"></div></div>
        <div class="modal-ft">
          <button class="btn btn-secondary" onclick="hideModal('${id}-modal')">Cancel</button>
          <button class="btn btn-primary" onclick="__crud['${id}'].save()">💾 Save</button>
        </div>
      </div>
    </div>`;

  function render() {
    const q = document.getElementById(id + '-q').value.toLowerCase().trim();
    let rows = cfg.store.all();
    if (cfg.sort) rows = rows.slice().sort(cfg.sort);
    if (q) rows = rows.filter(r => {
      const text = (cfg.searchText ? cfg.searchText(r) : JSON.stringify(r)).toLowerCase();
      return Algo.kmp(text, q).matches.length > 0;
    });
    const isAdmin = (Auth.current() || {}).role === 'admin';
    document.getElementById(id + '-body').innerHTML = rows.length
      ? rows.map(r => `<tr>${cfg.columns.map(c => `<td>${c.render(r)}</td>`).join('')}
          <td><div style="display:flex;gap:5px">
            <button class="btn btn-secondary btn-xs" onclick="__crud['${id}'].openEdit('${r.id}')">✏️</button>
            ${isAdmin ? `<button class="btn btn-danger btn-xs" onclick="__crud['${id}'].del('${r.id}')">🗑</button>` : ''}
          </div></td></tr>`).join('')
      : `<tr><td colspan="${cfg.columns.length + 1}" style="text-align:center;padding:32px;color:var(--text-4)">No records${q ? ' match your search' : ' yet'}</td></tr>`;
  }

  function buildForm(rec) {
    document.getElementById(id + '-form').innerHTML = cfg.fields.map(f => {
      const val = rec ? (rec[f.name] ?? '') : (f.default ?? '');
      let input;
      if (f.type === 'select') {
        input = `<select class="inp" id="${id}-f-${f.name}"><option value="">Select…</option>${
          optsOf(f).map(o => `<option value="${o.value}" ${String(o.value) === String(val) ? 'selected' : ''}>${o.label}</option>`).join('')}</select>`;
      } else {
        input = `<input class="inp" id="${id}-f-${f.name}" type="${f.type || 'text'}" value="${String(val).replace(/"/g, '&quot;')}"
          placeholder="${f.placeholder || ''}" ${f.min !== undefined ? `min="${f.min}"` : ''} ${f.max !== undefined ? `max="${f.max}"` : ''}>`;
      }
      const isPhone = /phone|contact/i.test(f.name);
      const errDiv = isPhone ? `<div id="${id}-f-${f.name}-err" style="display:none;margin-top:5px;font-size:12px;color:var(--red)">⚠ Enter a valid 10-digit phone number</div>` : '';
      return `<div class="form-group ${f.full ? 'form-full' : ''}"><label class="form-label">${f.label}${f.required ? ' <b>*</b>' : ''}</label>${input}${errDiv}</div>`;
    }).join('');
  }

  const api = {
    render,
    openAdd() { editId = null; document.getElementById(id + '-mt').textContent = cfg.addLabel || 'Add record'; buildForm(null); showModal(id + '-modal'); },
    openEdit(rid) { editId = rid; document.getElementById(id + '-mt').textContent = 'Edit record'; buildForm(cfg.store.find(rid)); showModal(id + '-modal'); },
    save() {
      const data = {};
      for (const f of cfg.fields) {
        let v = document.getElementById(`${id}-f-${f.name}`).value.trim();
        if (f.required && v === '') return toast(`${f.label} is required`, 'error');
        if (f.type === 'number') { v = v === '' ? 0 : parseFloat(v); if (isNaN(v)) return toast(`${f.label} must be a number`, 'error'); }
        if (/phone|contact/i.test(f.name) && v !== '') {
          const errEl = document.getElementById(`${id}-f-${f.name}-err`);
          const invalid = !/^[6-9]\d{9}$/.test(v);
          if (errEl) errEl.style.display = invalid ? 'block' : 'none';
          if (invalid) return toast(`${f.label}: enter a valid 10-digit phone number`, 'error');
        }
        data[f.name] = v;
      }
      if (cfg.validate) { const msg = cfg.validate(data); if (msg) return toast(msg, 'error'); }
      if (editId) { cfg.store.upd(editId, data); toast('Record updated ✅', 'success'); }
      else { const r = cfg.store.add(data); toast(`Added ${r.id} 🎉`, 'success'); }
      hideModal(id + '-modal'); render(); if (cfg.onChange) cfg.onChange();
    },
    del(rid) {
      if ((Auth.current() || {}).role !== 'admin') return toast('Only Administrators can delete records', 'error');
      confirm2('Delete this record?', () => { cfg.store.del(rid); toast('Deleted', 'warning'); render(); if (cfg.onChange) cfg.onChange(); });
    },
  };
  window.__crud[id] = api;
  render();
  return api;
}

/* badgeFor, statusCls, sevCls now live in app.js so every page can use them */
