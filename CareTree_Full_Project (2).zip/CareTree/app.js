/* ============================================================
   app.js — CareTree Shared Logic
   Smart Healthcare Resource & Emergency Management System
   ============================================================ */
'use strict';

/* ── LocalStorage DB ──────────────────────────────────────── */
const DB = {
  get(k, d = []) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v)      { localStorage.setItem(k, JSON.stringify(v)); },
  del(k)         { localStorage.removeItem(k); },
  clearAll() {
    ['ct_patients','ct_doctors','ct_ambulances','ct_emergencies','ct_inventory','ct_medicines','ct_labs','ct_appts','ct_invoices','ct_beds','ct_treecosts'].forEach(k => DB.del(k));
    toast('All hospital data cleared', 'warning');
  }
};

/* ── Seed default users ───────────────────────────────────── */
(function seed() {
  if (!localStorage.getItem('ct_users')) {
    DB.set('ct_users', [
      { id:'ADM001', name:'Dr. Meera Rao',   email:'admin@caretree.org',     password:'admin123', role:'admin',       designation:'Chief Coordinator',    phone:'9000000000' },
      { id:'CRD001', name:'Arjun Nair',      email:'arjun@caretree.org',     password:'crd123',   role:'coordinator', designation:'Emergency Coordinator',phone:'9111111111' },
    ]);
  }
  if (!localStorage.getItem('ct_keys')) {
    DB.set('ct_keys', [
      { id:'K1', name:'Patient Identity – EHR Lookup', category:'Patient',  freq:28, order:1 },
      { id:'K2', name:'Ambulance – ALS Unit',        category:'Transport',  freq:20, order:2 },
      { id:'K3', name:'Blood Bank – O Negative',     category:'Blood',      freq:5,  order:3 },
      { id:'K4', name:'ICU Bed – Cardiac',           category:'Bed',        freq:17, order:4 },
      { id:'K5', name:'Oxygen Cylinder Stock',       category:'Equipment',  freq:10, order:5 },
      { id:'K6', name:'Trauma Surgeon On-Call',      category:'Staff',      freq:20, order:6 },
      { id:'K7', name:'Ventilator – Portable',       category:'Equipment',  freq:3,  order:7 },
      { id:'K8', name:'Dialysis Machine',            category:'Equipment',  freq:25, order:8 },
      { id:'K9', name:'Patient Allergy/Medical Alert',category:'Patient',   freq:14, order:9 },
    ]);
  }
  if (!localStorage.getItem('ct_patients')) {
    DB.set('ct_patients', [
      { id:'P001', name:'Ravi Kumar',    age:54, gender:'Male',   condition:'Cardiac Arrest',      priority:'Critical', ward:'ICU-2',  needs:['ICU Bed','Ventilator'], allergy:'Penicillin', admitDate:'2026-09-20', contact:'9812340001' },
      { id:'P002', name:'Sunita Reddy',  age:29, gender:'Female', condition:'Road Trauma',         priority:'Critical', ward:'Trauma-1',needs:['ICU Bed','Specialist Doctor'], allergy:'None',       admitDate:'2026-09-22', contact:'9812340002' },
      { id:'P003', name:'Imran Sheikh',  age:67, gender:'Male',   condition:'Respiratory Distress',priority:'High',     ward:'ICU-4',  needs:['ICU Bed','Ventilator'], allergy:'Sulfa Drugs', admitDate:'2026-09-24', contact:'9812340003' },
      { id:'P004', name:'Lakshmi Iyer',  age:8,  gender:'Female', condition:'Severe Dehydration',  priority:'Moderate', ward:'Peds-1', needs:['Ward Bed','Specialist Doctor'], allergy:'None',       admitDate:'2026-09-25', contact:'9812340004' },
      { id:'P005', name:'Ahmed Khan',    age:41, gender:'Male',   condition:'Renal Failure',       priority:'High',     ward:'Dialysis',needs:['Dialysis Slot'], allergy:'Latex',      admitDate:'2026-09-26', contact:'9812340005' },
    ]);
  }
})();


/* ── Generic store factory (used by all hospital modules) ── */
function makeStore(key, prefix, seed) {
  if (!localStorage.getItem(key)) DB.set(key, seed);
  return {
    key, prefix,
    all()      { return DB.get(key, []); },
    save(l)    { DB.set(key, l); },
    find(id)   { return this.all().find(r => r.id === id); },
    genId()    { const l = this.all(); let n = 1; while (l.some(r => r.id === prefix + n)) n++; return prefix + n; },
    add(r)     { const l = this.all(); r.id = this.genId(); l.push(r); this.save(l); return r; },
    upd(id, d) { this.save(this.all().map(r => r.id === id ? { ...r, ...d } : r)); },
    del(id)    { this.save(this.all().filter(r => r.id !== id)); },
  };
}
const TODAY = new Date().toISOString().slice(0, 10);

const Doctors = makeStore('ct_doctors', 'D', [
  { id:'D1', name:'Dr. Anil Sharma',  specialization:'Cardiology',         shift:'Morning', phone:'9000011111', status:'On Duty' },
  { id:'D2', name:'Dr. Priya Menon',  specialization:'Trauma Surgery',     shift:'Night',   phone:'9000022222', status:'On Call' },
  { id:'D3', name:'Dr. Farhan Ali',   specialization:'Pulmonology',        shift:'Evening', phone:'9000033333', status:'On Duty' },
  { id:'D4', name:'Dr. Kavya Reddy',  specialization:'Pediatrics',         shift:'Morning', phone:'9000044444', status:'On Duty' },
  { id:'D5', name:'Dr. Rohit Verma',  specialization:'Nephrology',         shift:'Evening', phone:'9000055555', status:'Off Duty' },
  { id:'D6', name:'Dr. Sneha Patil',  specialization:'Emergency Medicine', shift:'Night',   phone:'9000066666', status:'On Duty' },
  { id:'D7', name:'Dr. Vikram Rao',   specialization:'Radiology',          shift:'Morning', phone:'9000077777', status:'On Duty' },
  { id:'D8', name:'Dr. Nisha Kapoor', specialization:'Anesthesiology',     shift:'Evening', phone:'9000088888', status:'On Call' },
]);
const Ambulances = makeStore('ct_ambulances', 'A', [
  { id:'A1', vehicle:'AMB-101', driver:'Suresh',  type:'ALS', zone:2, range:1, status:'Available' },
  { id:'A2', vehicle:'AMB-102', driver:'Mahesh',  type:'BLS', zone:4, range:1, status:'Available' },
  { id:'A3', vehicle:'AMB-103', driver:'Rafiq',   type:'ALS', zone:5, range:2, status:'Available' },
  { id:'A4', vehicle:'AMB-104', driver:'Joseph',  type:'BLS', zone:1, range:1, status:'Busy' },
]);
const Emergencies = makeStore('ct_emergencies', 'E', [
  { id:'E1', description:'Cardiac arrest at bus stand',  zone:2, severity:'Critical' },
  { id:'E2', description:'Road accident, two injured',   zone:3, severity:'Critical' },
  { id:'E3', description:'Breathing difficulty, elderly', zone:4, severity:'High' },
  { id:'E4', description:'Fall from staircase',          zone:5, severity:'Moderate' },
  { id:'E5', description:'High fever child',             zone:6, severity:'Low' },
]);
const Inventory = makeStore('ct_inventory', 'I', [
  { id:'I1', item:'Blood O Negative (units)', category:'Blood',      stock:4,  minLevel:10, restockCost:12, priority:10 },
  { id:'I2', item:'Oxygen Cylinders',          category:'Equipment',  stock:6,  minLevel:8,  restockCost:9,  priority:9 },
  { id:'I3', item:'Adrenaline Injections',     category:'Medicine',   stock:15, minLevel:20, restockCost:4,  priority:8 },
  { id:'I4', item:'Ventilator Circuits',       category:'Equipment',  stock:3,  minLevel:6,  restockCost:15, priority:7 },
  { id:'I5', item:'IV Fluid Bags',             category:'Consumable', stock:40, minLevel:30, restockCost:5,  priority:5 },
  { id:'I6', item:'Surgical Gloves (boxes)',   category:'Consumable', stock:8,  minLevel:15, restockCost:6,  priority:4 },
  { id:'I7', item:'Defibrillator Pads',        category:'Equipment',  stock:2,  minLevel:5,  restockCost:11, priority:8 },
  { id:'I8', item:'Insulin Vials',             category:'Medicine',   stock:12, minLevel:12, restockCost:7,  priority:6 },
]);
const Medicines = makeStore('ct_medicines', 'M', [
  { id:'M1',  name:'Paracetamol 500mg',    category:'Analgesic',    stock:500, price:2 },
  { id:'M2',  name:'Amoxicillin 250mg',    category:'Antibiotic',   stock:220, price:6 },
  { id:'M3',  name:'Azithromycin 500mg',   category:'Antibiotic',   stock:150, price:18 },
  { id:'M4',  name:'Metformin 500mg',      category:'Antidiabetic', stock:300, price:3 },
  { id:'M5',  name:'Atorvastatin 10mg',    category:'Cardiac',      stock:260, price:8 },
  { id:'M6',  name:'Amlodipine 5mg',       category:'Cardiac',      stock:240, price:4 },
  { id:'M7',  name:'Pantoprazole 40mg',    category:'Gastric',      stock:180, price:7 },
  { id:'M8',  name:'Cetirizine 10mg',      category:'Antiallergic', stock:400, price:2 },
  { id:'M9',  name:'Salbutamol Inhaler',   category:'Respiratory',  stock:90,  price:95 },
  { id:'M10', name:'Insulin Glargine',     category:'Antidiabetic', stock:60,  price:420 },
  { id:'M11', name:'Adrenaline Injection', category:'Emergency',    stock:70,  price:35 },
]);
const Labs = makeStore('ct_labs', 'L', [
  { id:'L1', patient:'Ravi Kumar',   test:'Troponin Panel',    start:'09:00', duration:70, priority:'STAT' },
  { id:'L2', patient:'Sunita Reddy', test:'Cross-match Blood', start:'09:30', duration:50, priority:'STAT' },
  { id:'L3', patient:'Imran Sheikh', test:'Arterial Blood Gas',start:'10:00', duration:40, priority:'Urgent' },
  { id:'L4', patient:'Lakshmi Iyer', test:'Electrolytes',      start:'10:30', duration:40, priority:'Urgent' },
  { id:'L5', patient:'Ahmed Khan',   test:'Creatinine / BUN',  start:'11:00', duration:30, priority:'Urgent' },
  { id:'L6', patient:'Ravi Kumar',   test:'Lipid Profile',     start:'09:00', duration:30, priority:'Routine' },
  { id:'L7', patient:'Imran Sheikh', test:'Chest X-ray Read',  start:'10:50', duration:20, priority:'Routine' },
  { id:'L8', patient:'Sunita Reddy', test:'CBC',               start:'08:30', duration:20, priority:'Routine' },
  { id:'L9', patient:'Lakshmi Iyer', test:'Culture Report',    start:'11:30', duration:60, priority:'Routine' },
]);
const Appts = makeStore('ct_appts', 'AP', [
  { id:'AP1', patientId:'P001', doctorId:'D1', date:TODAY, start:'09:00', end:'10:00', weight:5, status:'Requested' },
  { id:'AP2', patientId:'P003', doctorId:'D1', date:TODAY, start:'09:30', end:'10:30', weight:9, status:'Requested' },
  { id:'AP3', patientId:'P002', doctorId:'D1', date:TODAY, start:'10:00', end:'11:00', weight:4, status:'Requested' },
  { id:'AP4', patientId:'P005', doctorId:'D1', date:TODAY, start:'10:30', end:'11:30', weight:6, status:'Requested' },
  { id:'AP5', patientId:'P004', doctorId:'D1', date:TODAY, start:'11:00', end:'12:00', weight:3, status:'Requested' },
  { id:'AP6', patientId:'P004', doctorId:'D4', date:TODAY, start:'10:00', end:'10:45', weight:7, status:'Confirmed' },
  { id:'AP7', patientId:'P005', doctorId:'D5', date:TODAY, start:'14:00', end:'15:00', weight:6, status:'Confirmed' },
]);
const Beds = makeStore('ct_beds', 'W', [
  { id:'W1', ward:'ICU-A',      floor:2, type:'ICU',       capacity:8,  occupied:6 },
  { id:'W2', ward:'ICU-B',      floor:2, type:'ICU',       capacity:6,  occupied:5 },
  { id:'W3', ward:'Trauma-1',   floor:1, type:'Trauma',    capacity:10, occupied:7 },
  { id:'W4', ward:'General-A',  floor:3, type:'General',   capacity:20, occupied:12 },
  { id:'W5', ward:'General-B',  floor:3, type:'General',   capacity:20, occupied:9 },
  { id:'W6', ward:'Pediatrics', floor:4, type:'Pediatric', capacity:12, occupied:4 },
  { id:'W7', ward:'Isolation',  floor:1, type:'Isolation', capacity:6,  occupied:2 },
]);
const Invoices = makeStore('ct_invoices', 'B', [
  { id:'B1', patientId:'P001', description:'ICU stay (2 days)',       amount:24000, insurancePct:70, status:'Pending', date:TODAY },
  { id:'B2', patientId:'P002', description:'Trauma surgery',          amount:56000, insurancePct:60, status:'Pending', date:TODAY },
  { id:'B3', patientId:'P003', description:'Ventilator support',      amount:18000, insurancePct:50, status:'Paid',    date:TODAY },
  { id:'B4', patientId:'P004', description:'Pediatric ward + fluids', amount:6500,  insurancePct:0,  status:'Paid',    date:TODAY },
  { id:'B5', patientId:'P005', description:'Dialysis session',        amount:4200,  insurancePct:80, status:'Paid',    date:TODAY },
  { id:'B6', patientId:'P001', description:'Cardiac lab panel',       amount:3800,  insurancePct:70, status:'Pending', date:TODAY },
]);

/* helpers used across pages */
function patientName(id) { const p = Patients.find(id); return p ? p.name : id; }
function toMin(t) { const [h, m] = t.split(':').map(Number); return h * 60 + m; }
function fromMin(x) { return String(Math.floor(x / 60)).padStart(2, '0') + ':' + String(x % 60).padStart(2, '0'); }

/* ── Auth ─────────────────────────────────────────────────── */
const Auth = {
  current() { return DB.get('ct_currentUser', null); },
  login(email, pwd) {
    const u = DB.get('ct_users',[]).find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === pwd);
    if (u) DB.set('ct_currentUser', u);
    return u || null;
  },
  logout()   { DB.del('ct_currentUser'); location.href = 'index.html'; },
  guard()    { if (!this.current()) { location.href = 'index.html'; return false; } return true; },
  adminOnly(){ if (!this.current() || this.current().role !== 'admin') { location.href = 'dashboard.html'; return false; } return true; }
};

/* ── Patients ─────────────────────────────────────────────── */
const Patients = {
  all()     { return DB.get('ct_patients', []); },
  save(l)   { DB.set('ct_patients', l); },
  add(p)    { const l=this.all(); l.push(p); this.save(l); },
  upd(id,d) { this.save(this.all().map(p=>p.id===id?{...p,...d}:p)); },
  del(id)   { this.save(this.all().filter(p=>p.id!==id)); },
  find(id)  { return this.all().find(p=>p.id===id); },
  genId()   { const l=this.all(); let n=1; while(l.some(p=>p.id==='P'+String(n).padStart(3,'0'))) n++; return 'P'+String(n).padStart(3,'0'); }
};

/* ── Users ────────────────────────────────────────────────── */
const Users = {
  all()  { return DB.get('ct_users', []); },
  save(l){ DB.set('ct_users', l); },
  upd(id,d){ this.save(this.all().map(u=>u.id===id?{...u,...d}:u)); },
};

/* ── Toast ────────────────────────────────────────────────── */
function toast(msg, type = 'success', ms = 3400) {
  let c = document.getElementById('toasts');
  if (!c) { c = document.createElement('div'); c.id = 'toasts'; document.body.appendChild(c); }
  const icons = { success:'✅', error:'❌', warning:'⚠️', info:'ℹ️' };
  const el = document.createElement('div');
  el.className = `toast t-${type}`;
  el.innerHTML = `<span style="font-size:17px">${icons[type]||icons.info}</span><span class="toast-msg">${msg}</span><span class="toast-x" onclick="this.parentElement.remove()">✕</span>`;
  c.appendChild(el);
  setTimeout(() => { el.style.animation='toastOut .3s ease forwards'; setTimeout(()=>el.remove(),300); }, ms);
}

/* ── Modal helpers ────────────────────────────────────────── */
function showModal(id)  { const el=document.getElementById(id); if(el){el.classList.add('show'); document.body.style.overflow='hidden';} }
function hideModal(id)  { const el=document.getElementById(id); if(el){el.classList.remove('show'); document.body.style.overflow='';} }
document.addEventListener('click', e => {
  if (e.target.classList.contains('overlay')) { e.target.classList.remove('show'); document.body.style.overflow=''; }
});

function confirm2(msg, onYes) {
  let ov = document.getElementById('confirm-ov');
  if (!ov) {
    document.body.insertAdjacentHTML('beforeend', `
      <div class="overlay" id="confirm-ov">
        <div class="modal modal-sm">
          <div class="modal-hd">
            <div class="modal-hd-icon">⚠️</div>
            <div class="modal-title">Confirm</div>
            <button class="modal-close" onclick="hideModal('confirm-ov')">✕</button>
          </div>
          <div class="modal-body"><p id="confirm-msg" style="font-size:14px;color:var(--text-3);line-height:1.7"></p></div>
          <div class="modal-ft">
            <button class="btn btn-secondary" onclick="hideModal('confirm-ov')">Cancel</button>
            <button class="btn btn-danger"    id="confirm-yes">Yes, Confirm</button>
          </div>
        </div>
      </div>`);
    ov = document.getElementById('confirm-ov');
  }
  document.getElementById('confirm-msg').textContent = msg;
  showModal('confirm-ov');
  const yBtn = document.getElementById('confirm-yes');
  yBtn.onclick = () => { hideModal('confirm-ov'); onYes(); };
}

/* ── Sidebar / Topbar ─────────────────────────────────────── */
function renderSidebar(active) {
  const u = Auth.current();
  if (!u) return;
  const groups = [
    { label:'Hospital Modules', items:[
      { id:'dashboard',   icon:'📊', label:'Dashboard',          href:'dashboard.html' },
      { id:'patients',    icon:'🧑‍🤝‍🧑', label:'Patients',          href:'patients.html' },
      { id:'doctors',     icon:'👨‍⚕️', label:'Doctors & Roster',   href:'doctors.html' },
      { id:'appointments',icon:'📅', label:'Appointments',        href:'appointments.html' },
      { id:'beds',        icon:'🛏️', label:'Beds & Wards',        href:'beds.html' },
      { id:'emergency',   icon:'🚑', label:'Emergency & Dispatch',href:'emergency.html' },
      { id:'inventory',   icon:'📦', label:'Inventory & Blood',   href:'inventory.html' },
      { id:'pharmacy',    icon:'💊', label:'Pharmacy & Lab',      href:'pharmacy.html' },
      { id:'billing',     icon:'🧾', label:'Billing',             href:'billing.html', adminOnly:true },
    ]},
    { label:'Account', items:[
      { id:'profile',     icon:'👤', label:'My Profile',          href:'profile.html' },
    ]},
  ].map(g => ({ ...g, items: g.items.filter(i => !i.adminOnly || u.role === 'admin') }));
  const el = document.querySelector('.sidebar');
  if (!el) return;
  el.innerHTML = `
    <div class="sidebar-head">
      <div class="s-logo">🌳</div>
      <div class="s-brand">
        <div class="s-name">CareTree</div>
        <div class="s-sub">Hospital Management System</div>
      </div>
    </div>
    <div class="sidebar-body">
      ${groups.map(g => `
        <div class="nav-group-label">${g.label}</div>
        ${g.items.map(item => `
        <a href="${item.href}" class="nav-item ${active===item.id?'active':''}">
          <div class="ni-icon">${item.icon}</div>
          <span>${item.label}</span>
        </a>`).join('')}`).join('')}
    </div>
    <div class="sidebar-foot">
      <div class="s-user" onclick="location.href='profile.html'">
        <div class="s-avatar">${u.name.charAt(0)}</div>
        <div class="s-user-info">
          <div class="s-uname">${u.name}</div>
          <div class="s-urole">${u.role==='admin'?'Administrator':u.designation||'Coordinator'}</div>
        </div>
      </div>
      <button class="s-logout" onclick="Auth.logout()">🚪 Sign Out</button>
    </div>`;
}

function renderTopbar(title) {
  const u  = Auth.current();
  const el = document.querySelector('.topbar');
  if (!el || !u) return;
  el.innerHTML = `
    <div class="topbar-left"><div class="tb-page-title">${title}</div></div>
    <div class="topbar-right">
      <button class="tb-icon-btn" onclick="location.href='appointments.html'">📅</button>
      <button class="tb-icon-btn" onclick="location.href='beds.html'">🛏️</button>
      <div class="tb-user-chip" onclick="location.href='profile.html'">
        <div class="tb-chip-avatar">${u.name.charAt(0)}</div>
        <span class="tb-chip-name">${u.name}</span>
      </div>
    </div>`;
}

/* ── Utils ────────────────────────────────────────────────── */
function uid() { return Date.now().toString(36)+Math.random().toString(36).slice(2,6); }
function fmtDT(ts) { return new Date(ts).toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}); }
function catBadge(c) {
  const m={Patient:'b-blue',Transport:'b-navy',Blood:'b-red',Bed:'b-violet',Equipment:'b-amber',Staff:'b-green',Medication:'b-navy'};
  return m[c]||'b-navy';
}
function priorityBadge(p) {
  const m={Critical:'b-red',High:'b-amber',Moderate:'b-blue',Low:'b-green'};
  return m[p]||'b-navy';
}
function round2(x){ return Math.round(x*100)/100; }
const badgeFor = (text, cls) => `<span class="badge ${cls}"><span class="badge-dot"></span>${text}</span>`;
const statusCls = s => ({ 'On Duty':'b-green','Available':'b-green','Paid':'b-green','Confirmed':'b-green','On Call':'b-amber','Pending':'b-amber','Requested':'b-blue','Off Duty':'b-navy','Busy':'b-red','Cancelled':'b-red' }[s] || 'b-navy');
const sevCls = s => ({ Critical:'b-red', High:'b-amber', Moderate:'b-blue', Low:'b-green', STAT:'b-red', Urgent:'b-amber', Routine:'b-green' }[s] || 'b-navy');
